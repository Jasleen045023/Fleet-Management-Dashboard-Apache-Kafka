# Last amended: 16th Dec, 2024
# Confluent schemas:
#   https://github.com/confluentinc/kafka-connect-datagen/tree/master/src/main/resources

# Related file: 
#	convert.py in ~/Documents/fake folder

# Related file: 
#	genData.sh in $HOME folder

# Objective:
#     Given a json file with each row having a json object, such as:
#	{"id":1,"f1":34,"f2":56}
#       {"id":2,"f2":34,"f3":56}
#     Outputs key:value pair:
#	1:{"id":1,"f1":34,"f2":56}
#	2:{"id":2,"f2":34,"f3":56}	
#
#
# Usage: 
#			python $HOME/Documents/fake/convert.py
#			
#


# https://www.geeksforgeeks.org/how-to-convert-python-dictionary-to-json/
# https://www.geeksforgeeks.org/how-to-convert-python-dictionary-to-json/

import json



print(" ")
print("=================")
print("Will transform each row of json data to key:value format")
filename = input("What is your json file name (in folder ~/Documents/gendata)? ")

myfolder = "/home/ashok/Documents/gendata/"

data = [json.loads(line) for line in open(myfolder +  filename , 'r')]

for line in data:
    d = list(line.values())
    out = json.dumps(line)
    dv = str(d[0]) +":" + out+"\n"
    with open(myfolder+"rev_" + filename, "a") as outfile: 
        outfile.write(dv)

print(" ")
print("=================")
print("The converted file is: rev_" + filename + " in the ~/Documents/gendata folder")
print("=================")

   
